<?php
  $page_title = "Login";
  require 'includes/nav_old.php';
?>

<!-- NOT NAV -->
<main class="not-nav">

  <?php

    include 'includes/inner_login.php';

    include 'includes/footer.php';
  ?>

</main>
