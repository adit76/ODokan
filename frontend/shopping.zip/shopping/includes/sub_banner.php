<link rel="stylesheet" href="css/sub_banner.css">

<!-- Ad kinda Banners -->
<div class="banner_container">
  <div class="sub_banner sub_banner_1" style="background: url('https://cdn11.bigcommerce.com/s-14045/product_images/theme_images/hp-banner-cozy-collection__02468.jpg?t=1543116413');">
      <div class="sub_banner_left pull-left">
        <p class="title">SHOP MOST WANTED BRANDS</p><br/>
        <p class="sub_title">Nike, Libas, W, Mango, High Lander and more most wanted brands at a very reasonable price </p><br/>
        <button class="btn btn-primary">SHOP NOW</button>
      </div>
  </div>

  <div class="sub_banner sub_banner_1" style="background: url('https://s3.amazonaws.com/jenni-kayne/media/cmsimage/2368/desktop/Jenni_Kayne-Banner-Sweaters.jpg?1539897628');">
      <div class="sub_banner_right pull-right">
        <p class="title">GET 50% OFF</p><br/>
        <p class="sub_title">This Festive Season Get 50% Off On any items for limited time.</p><br/>
        <button class="btn btn-primary">SHOP NOW</button>
      </div>
  </div>
</div>
