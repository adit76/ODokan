<link rel="stylesheet" href="css/sub_banner.css">

<!-- Ad kinda Banners -->
<div class="banner_container container">
  <div class="sub_banner sub_banner_1" style="background: url('https://s3.amazonaws.com/jenni-kayne/media/cmsimage/2368/desktop/Jenni_Kayne-Banner-Sweaters.jpg?1539897628');">
      <div class="sub_banner_right pull-right">
        <p class="title">GET 50% OFF</p><br/>
        <p class="sub_title">This Festive Season Get 50% Off On any items for limited time.</p><br/>
        <button class="btn btn-primary"><a href="products.php">SHOP NOW</a></button>
      </div>
  </div>
</div>
