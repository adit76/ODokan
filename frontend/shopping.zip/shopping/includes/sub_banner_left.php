<link rel="stylesheet" href="css/sub_banner.css">

<!-- Ad kinda Banners -->
<div class="banner_container container">
  <div class="sub_banner sub_banner_1" style="background: url('https://i.imgur.com/0pSDhnC.png');">
      <div class="sub_banner_left pull-left">
        <p class="title">INTERIOR DESIGN</p><br/>
        <p class="sub_title">Kitchen, Bedroom, Bathroom, Living Rooms and Restaurants Design.</p><br/>
        <button class="btn btn-primary">Order Now</button>
      </div>
  </div>
</div>
