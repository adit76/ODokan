<?php
  $page_title = "Forget Password";
  require 'includes/nav_old.php';
?>

<!-- NOT NAV -->
<main class="not-nav">

  <?php

    include 'includes/inner_forget.php';

    include 'includes/footer.php';
  ?>

</main>
