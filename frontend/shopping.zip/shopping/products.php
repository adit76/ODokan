<?php
  $page_title = "Mens Products";
  require 'includes/nav_old.php';
?>

<!-- NOT NAV -->
<main class="not-nav">

  <?php
    include 'includes/inner_products.php';

    include 'includes/mobile_ad.php';

    include 'includes/footer.php';
  ?>

</main>
