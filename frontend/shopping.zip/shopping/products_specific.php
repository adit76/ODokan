<?php
  $page_title = "Mens Products";
  require 'includes/nav_old.php';
?>

<!-- NOT NAV -->
<main class="not-nav">

  <?php
    include 'includes/inner_products_specific.php';

    include 'includes/footer.php';
  ?>

</main>
