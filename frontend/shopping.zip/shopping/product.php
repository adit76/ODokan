<?php
  $page_title = "Jeans Trousers";
  require 'includes/nav_old.php';
?>

<!-- NOT NAV -->
<main class="not-nav">

  <?php
    include 'includes/product_details.php';

    echo '<br/><br/>';

    include 'includes/arrivals.php';

    include 'includes/footer.php';
  ?>

</main>
